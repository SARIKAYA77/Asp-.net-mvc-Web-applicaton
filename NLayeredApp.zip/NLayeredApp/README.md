# NLayeredAppDemo
.NET multi layered application demo with Northwind Database

## NuGet Packages:
- Entity Framework (Data access technology)
- Fluent Validation (Validation library)
- Ninject (Dependency injector)
